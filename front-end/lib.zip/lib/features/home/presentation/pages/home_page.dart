import 'package:flutter/material.dart';
import '../../../../core/constants/colors/app_colors.dart';
import '../../../../core/navigation/app_navigator.dart';
import '../../../../core/routes/app_routes.dart';
import '../widgets/home_top_bar.dart';
import '../widgets/home_search_bar.dart';
import '../widgets/promo_card.dart';
import '../widgets/category_item.dart';
import '../widgets/offer_card.dart';
import '../widgets/pharmacy_card.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _navIndex = 0;

  void _onNavTap(int index) {
    if (index == _navIndex) return;
    setState(() => _navIndex = index);
    switch (index) {
      case 2:
        AppNavigator.pushNamed(context, AppRoutes.mapScreen);
        break;
      case 3:
        AppNavigator.pushNamed(context, AppRoutes.chatbot);
        break;
      case 4:
        AppNavigator.pushNamed(context, AppRoutes.profile);
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final primary = AppColors.primary(dark);
    final accent = AppColors.accent(dark);
    final secondary = AppColors.secondary(dark);
    final bg = AppColors.background(dark);
    final card = AppColors.card(dark);
    final fg = AppColors.fg(dark);
    final muted = AppColors.muted(dark);

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              HomeTopBar(
                  primaryColor: primary, accentColor: accent, cardColor: card),

              // Location pill
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Icon(Icons.location_on, color: primary, size: 18),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        'Cairo, Egypt',
                        style: TextStyle(
                            color: fg,
                            fontSize: 14,
                            fontWeight: FontWeight.w500),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom(
                          padding: EdgeInsets.zero, minimumSize: Size.zero),
                      child: Text('Change',
                          style: TextStyle(color: primary, fontSize: 13)),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 14),
              HomeSearchBar(
                  cardColor: card,
                  mutedForegroundColor: muted,
                  foregroundColor: fg),
              const SizedBox(height: 20),

              // Promo cards
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(children: [
                  Expanded(
                      child: PromoCard(
                          icon: Icons.access_time_rounded,
                          iconColor: primary,
                          largeText: '30 min',
                          smallText: 'Fast delivery',
                          cardColor: card,
                          textColor: fg,
                          mutedColor: muted)),
                  const SizedBox(width: 12),
                  Expanded(
                      child: PromoCard(
                          icon: Icons.percent_rounded,
                          iconColor: accent,
                          largeText: '20% off',
                          smallText: 'First order',
                          cardColor: card,
                          textColor: fg,
                          mutedColor: muted)),
                ]),
              ),
              const SizedBox(height: 28),

              // Categories
              _SectionHeader(
                  title: 'Categories',
                  actionLabel: 'See all',
                  primary: primary,
                  fg: fg),
              const SizedBox(height: 14),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CategoryItem(
                        icon: Icons.medication_rounded,
                        label: 'Medicines',
                        color: primary,
                        cardColor: card,
                        textColor: fg),
                    CategoryItem(
                        icon: Icons.favorite_border_rounded,
                        label: 'Vitamins',
                        color: primary,
                        cardColor: card,
                        textColor: fg),
                    CategoryItem(
                        icon: Icons.water_drop_outlined,
                        label: 'Skin care',
                        color: primary,
                        cardColor: card,
                        textColor: fg),
                    CategoryItem(
                        icon: Icons.monitor_heart_outlined,
                        label: 'Devices',
                        color: primary,
                        cardColor: card,
                        textColor: fg),
                  ],
                ),
              ),
              const SizedBox(height: 28),

              // Nearby pharmacies
              _SectionHeader(
                  title: 'Nearby pharmacies',
                  actionLabel: 'See all',
                  primary: primary,
                  fg: fg,
                  onAction: () =>
                      AppNavigator.pushNamed(context, AppRoutes.mapScreen)),
              const SizedBox(height: 14),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(children: [
                  PharmacyCard(
                      name: 'El Ezaby – Maadi',
                      address: '10 Road 9, Maadi',
                      rating: 4.7,
                      distance: '0.8 km',
                      isOpen: true,
                      primaryColor: primary,
                      accentColor: accent,
                      cardColor: card,
                      foregroundColor: fg,
                      mutedColor: muted),
                  const SizedBox(height: 10),
                  PharmacyCard(
                      name: 'Seif – Dokki',
                      address: '3 Tahrir St, Dokki',
                      rating: 4.5,
                      distance: '1.4 km',
                      isOpen: true,
                      primaryColor: primary,
                      accentColor: accent,
                      cardColor: card,
                      foregroundColor: fg,
                      mutedColor: muted),
                ]),
              ),
              const SizedBox(height: 28),

              // Offers
              _SectionHeader(
                  title: 'Offers for you',
                  actionLabel: 'View all',
                  primary: primary,
                  fg: fg),
              const SizedBox(height: 14),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(children: [
                  OfferCard(
                      icon: Icons.local_offer_outlined,
                      iconColor: accent,
                      iconBackgroundColor: accent.withOpacity(0.15),
                      title: 'Summer health sale',
                      discount: '40% OFF',
                      description: 'On vitamins and supplements',
                      validity: 'Valid until July 31',
                      primaryColor: primary,
                      cardColor: card,
                      foregroundColor: fg,
                      mutedColor: muted),
                  const SizedBox(height: 10),
                  OfferCard(
                      icon: Icons.percent_rounded,
                      iconColor: primary,
                      iconBackgroundColor: primary.withOpacity(0.15),
                      title: 'First order special',
                      discount: '20% OFF',
                      description: 'Use code: FIRST20',
                      validity: 'For new customers',
                      primaryColor: primary,
                      cardColor: card,
                      foregroundColor: fg,
                      mutedColor: muted),
                  const SizedBox(height: 10),
                  OfferCard(
                      icon: Icons.local_shipping_outlined,
                      iconColor: secondary,
                      iconBackgroundColor: secondary.withOpacity(0.15),
                      title: 'Free delivery',
                      discount: 'FREE',
                      description: 'On orders above EGP 500',
                      validity: 'This month only',
                      primaryColor: primary,
                      cardColor: card,
                      foregroundColor: fg,
                      mutedColor: muted),
                  const SizedBox(height: 24),
                ]),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _navIndex,
        onDestinationSelected: _onNavTap,
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home_rounded),
              label: 'Home'),
          NavigationDestination(
              icon: Icon(Icons.map_outlined),
              selectedIcon: Icon(Icons.map_rounded),
              label: 'Map'),
          NavigationDestination(
              icon: Icon(Icons.chat_bubble_outline_rounded),
              selectedIcon: Icon(Icons.chat_bubble_rounded),
              label: 'Chat'),
          NavigationDestination(
              icon: Icon(Icons.person_outline_rounded),
              selectedIcon: Icon(Icons.person_rounded),
              label: 'Profile'),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final String actionLabel;
  final Color primary;
  final Color fg;
  final VoidCallback? onAction;

  const _SectionHeader(
      {required this.title,
      required this.actionLabel,
      required this.primary,
      required this.fg,
      this.onAction});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title,
              style: TextStyle(
                  color: fg, fontSize: 18, fontWeight: FontWeight.bold)),
          TextButton(
            onPressed: onAction ?? () {},
            style: TextButton.styleFrom(
                padding: EdgeInsets.zero, minimumSize: Size.zero),
            child: Text(actionLabel,
                style: TextStyle(
                    color: primary, fontSize: 13, fontWeight: FontWeight.w500)),
          ),
        ],
      ),
    );
  }
}
