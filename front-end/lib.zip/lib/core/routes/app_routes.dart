class AppRoutes {
  AppRoutes._();
  static const String auth = '/auth';
  static const String login = '/login';
  static const String signup = '/signup';
  static const String home = '/';
  static const String mapScreen = '/map';
  static const String profile = '/profile';
  static const String chatbot = '/chatbot';
}
